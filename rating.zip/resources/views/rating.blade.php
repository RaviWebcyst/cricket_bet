<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <title>Rating</title>
</head>
<body>
    <div class="container mt-5 col-md-6">
      <h6>Team A : <span class="team_a"></span> </h6> 
      <div>
        <table class="table mt-1">
            <thead>
                <tr>
                    <th>Rate1</th>
                    <th>Rate2</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td data-toggle="modal" data-target="#rate1"  id="rt_{{str_replace(".","",$rate->rate1)}}" onclick="rate('{{$rate->rate1}}')" data-id="{{$rate->rate1}}">{{$rate->rate1}}</td>
                    <td data-toggle="modal" data-target="#rate2"  id="rt_{{str_replace(".","",$rate->rate2)}}" onclick="rate('{{$rate->rate2}}')">{{$rate->rate2}}</td>
                </tr>
            </tbody>
            <thead>
                <tr>
                    <th>Rate3</th>
                    <th>Rate4</th>
                </tr>
            </thead>
            <tbody>
                <tr>  
                    <td data-toggle="modal" data-target="#rate3"  id="rt_{{str_replace(".","",$rate->rate3)}}" onclick="rate('{{$rate->rate3}}')">{{$rate->rate3}}</td>
                    <td data-toggle="modal" data-target="#rate4"  id="rt_{{str_replace(".","",$rate->rate4)}}" onclick="rate('{{$rate->rate4}}')">{{$rate->rate4}}</td>
                </tr>
            </tbody>
        </table>
    </div>
<h5>Team B: <span class="team_b"></span></h5>

        <div class="justify-content-center mt-5">
            <div class="card">
                <div class="card-header">
                    Rates
                </div>
                <div class="card-body">
                    <form action="{{route('rate.store')}}" method="post">
                        @csrf
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="">Rate1</label>
                                <input type="text" class="form-control" name="rate1" required >
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Rate2</label>
                                <input type="text" class="form-control" name="rate2" required >
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Rate3</label>
                                <input type="text" class="form-control" name="rate3" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Rate4</label>
                                <input type="text" class="form-control" name="rate4" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>


       
    </div>


    <div class="modal fade" id="rate1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form class="form-inline">
                    <div class="form-group mb-2">
                      <input type="hidden" class="form-control"  name="rate" id="rat1">
                      <input type="text" class="form-control"  id="calrat1" name="calrat" value="1000">
                    </div>
                    <button type="button" class="btn btn-primary mb-2 ml-auto cal1">Calculate</button>
                </form>
                <div class="row">
                  <div class="col-md-3"><button class="btn btn-light" onclick="btn_val(1000)">1000</button></div>
                  <div class="col-md-3"><button class="btn btn-light" onclick="btn_val(5000)">5000</button></div>
                  <div class="col-md-3"><button class="btn btn-light" onclick="btn_val(10000)">10000</button></div>
                  <div class="col-md-3"><button class="btn btn-light" onclick="btn_val(25000)">25000</button></div>
                </div>
                <div class="row mt-2">
                  <div class="col-md-3"><button class="btn btn-light" onclick="btn_val(50000)">50000</button></div>
                  <div class="col-md-3"><button class="btn btn-light" onclick="btn_val(100000)">100000</button></div>
                  <div class="col-md-3"><button class="btn btn-light" onclick="btn_val(200000)">200000</button></div>
                  <div class="col-md-3"><button class="btn btn-light" onclick="btn_val(500000)">500000</button></div>
                </div>
            </div>
          </div>
        </div>
      </div>
    
      <script>
        function rate(data){
          $(document).ready(function(){
            var data1 = data.replace(".","");
            $(".modal").attr("id","rate_"+data1);
            $("#rate_"+data1).modal("show");
            var rate1 = $("#rt_"+data1).text();
            $("#rat1").val(rate1);
          });
        }
        
        function btn_val(data){
          document.getElementById("calrat1").value = data;
        }

        
      $(document).ready(function(){
        var val =1;
        $(".cal1").click(function(){
          $(".team_a").text("");
          $(".team_b").text("");
          var calrate = $("#calrat1").val();
          var rate = $("#rat1").val();
          var team_a = (rate-val)*calrate;
          $(".team_a").text(Math.round(team_a));
          $(".team_b").text(-calrate);
          $(".modal").modal("hide");
        });
        });

      </script>
</body>
</html>