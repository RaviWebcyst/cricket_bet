<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redis;
use App\rate;

class RateController extends Controller
{

    public function index(){
        $rate = rate::latest()->first();
        return view("rating",compact('rate'));
    }

    public function store(Request $request){
        rate::create([
            "rate1"=>$request->rate1,
            "rate2"=>$request->rate2,
            "rate3"=>$request->rate3,
            "rate4"=>$request->rate4
        ]);

        return redirect()->back();
    }
}
